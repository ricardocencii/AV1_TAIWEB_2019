<?php

    include_once '../controle/controleAutomovel.php';
    include_once '../controle/controleCliente.php';

    if( !empty($_POST['form_submit']) ) {
        controleAutomovel::confirmar();
    }

    if( !empty($_POST['form_submit2'])) {
        $num1 = $_POST["n1"];
        $num2 = $_POST["n2"];
        $soma = $num1+$num2;

        echo "<script>alert('A soma é: ' + $soma);</script>";
        unset($_POST["n1"]);
        unset($_POST["n1"]);
    }
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>

    <script  language="text/javascript">
    function somar(){
     var n1= parseInt(getElementById("n1").value);
     var n2= parseInt(getElementById("n2").value);

     var soma= n1+n2;
        /*document.getElementById("soma").innerHTML = soma;*/
    javascript:alert("A soma é: "+ soma);
    }
    </script>

    <link rel="icon" href="img/favicon.ico">
    <title>SiGer</title>
    <!-- Bootstrap URL - CSS -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <link href="../../recursos/css/theme.css" rel="stylesheet">
    <!-- Ajax Script -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.js" integrity="sha256-fNXJFIlca05BIO2Y5zh1xrShK3ME+/lYZ0j+ChxX2DA=" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  </head>

  <body role="document">
    <!-- Fixed navbar -->
    <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">[ SisGer ] Sistema Gerenciador de Certificado</a>
        </div>
	<div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
              <li class="active">
                      <a href="../index.php"> Início </a>
              </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container theme-showcase" role="main">
    <br>
        <div class="page-header">
            <h2 class="form-signin-heading">
                <div id="m_texto"> Cadastrar Automovel </div>
            </h2>
        </div>

        <form class="form" method="post" action="viewAutomovelCadastrar.php">
            <input TYPE="hidden" NAME="form_submit" VALUE="OK">
            <div class='row'>
                <div class="col-sm-3">
                    <label>Placa: </label>
                    <input type="text" name="placa" class="form-control">
                </div>
                <div class="col-sm-3">
                    <label>Fabricante: </label>
                    <input type="text" name="fabricante" class="form-control">
                </div>
                <div class="col-sm-3">
                    <label>Modelo: </label>
                    <input type="text" name="modelo" class="form-control">
                </div>
                <div class="col-sm-3">
                    <label>Clientes: </label><br>
                    <select class="form-control">
                    <?php
                        controleCliente::loadClientes();
                    ?>
                    </select>
                </div>
            </div><br>
            <button type="submit" name="acao" value="confirmar/0" class="btn btn-success btn-block">
                <b>Confirmar</b>
            </button>
        </form>

        <form action="viewAutomovelCadastrar.php" method="POST">
            <input TYPE="hidden" NAME="form_submit2" VALUE="OK">
            <div class='row'>
                <h3>Calculo</h3>
                <div class="col-sm-3">
                    <label>Número 1: </label>
                    <input type="text" name="n1" class="form-control">
                </div>
                <div class="col-sm-3">
                    <label>Número 2: </label>
                    <input type="text" name="n2" class="form-control">                    
                </div>
                <div class="col-sm-3">
                    <label></label><br>
                    <button type="submit" class="btn btn-primary">Somar</button>
                </div>
            </div>
        </form>
        </div>

	<div class="page-header">
		<b>&copy;2019&nbsp;&nbsp;&raquo;&nbsp;&nbsp; </b>
	</div>
    </div> <!-- /container -->
  </body>
</html>
