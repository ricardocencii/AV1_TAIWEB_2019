<?php

    include_once '../DB.php';

    class modeloAutomovel extends DB {

        public static $tabela = 'tb_automovels';

        public static function getAutomovels() {

            return parent::selectAll(self::$tabela, "ORDER BY id desc");
        }

        public static function findAutomovel($id) {

            return parent::selectFind(self::$tabela, $id);
        }

        public static function addAutomovel($dados_automovel) {

            return parent::insert(self::$tabela, $dados_automovel);
        }

        public static function upAutomovel($dados) {

            return parent::update(self::$tabela, $dados);
        }

        public static function delAutomovel($id) {

            return parent::delete(self::$tabela, $id);
        }
    }
