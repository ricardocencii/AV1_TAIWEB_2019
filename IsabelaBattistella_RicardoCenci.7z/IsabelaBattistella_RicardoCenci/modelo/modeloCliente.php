<?php

    include_once '../DB.php';

    class modeloCliente extends DB {

        public static $tabela = 'tb_clientes';

        public static function getClientes() {

            return parent::selectAll(self::$tabela, "ORDER BY id desc");
        }

        public static function findCliente($id) {

            return parent::selectFind(self::$tabela, $id);
        }

        public static function addCliente($dados_cliente) {

            return parent::insert(self::$tabela, $dados_cliente);
        }

        public static function upCliente($dados) {

            return parent::update(self::$tabela, $dados);
        }

        public static function delCliente($id) {

            return parent::delete(self::$tabela, $id);
        }
    }
