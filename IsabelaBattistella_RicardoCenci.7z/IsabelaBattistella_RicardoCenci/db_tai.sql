-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 11-Set-2019 às 14:45
-- Versão do servidor: 5.7.24
-- versão do PHP: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tai`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_automovels`
--

DROP TABLE IF EXISTS `tb_automovels`;
CREATE TABLE IF NOT EXISTS `tb_automovels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `placa` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `fabricante` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `modelo` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `tb_automovels`
--

INSERT INTO `tb_automovels` (`id`, `placa`, `fabricante`, `modelo`) VALUES
(3, 'MMM-0000', 'VW', 'GOLFAO REBAXADO'),
(4, 'MMM-1111', 'Fiat', 'UNO DE FIRMA'),
(5, 'MMM-2222', 'FORD', 'SAVEIRO CAÇAMBINHA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_clientes`
--

DROP TABLE IF EXISTS `tb_clientes`;
CREATE TABLE IF NOT EXISTS `tb_clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `telefone` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `cpf` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Extraindo dados da tabela `tb_clientes`
--

INSERT INTO `tb_clientes` (`id`, `nome`, `telefone`, `cpf`, `email`) VALUES
(7, 'Ricardo', '33533156', '4546678686', 'rikaaaceeenci@hotmail.com'),
(6, 'Isabela', '33534400', '4546678686', 'isabela_xxm@hotmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
