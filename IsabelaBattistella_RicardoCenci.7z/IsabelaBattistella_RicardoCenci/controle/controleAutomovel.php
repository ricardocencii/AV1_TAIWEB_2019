<?php

include_once '../modelo/modeloAutomovel.php';

class controleAutomovel
{
    public static function index()
    {
        echo "<script>window.location='../view/viewAutomovelCadastrar.php'</script>";
    }

    public static function remover($id)
    {
        $automovel = modeloAutomovel::findAutomovel($id);

        if (empty($automovel)) {
            echo "<script>alert('O ID informado para o automovel não existe!')</script>";
            echo "<script>window.location='viewAutomovel.php'</script>";
        } else {
            modeloAutomovel::delAutomovel($id);
            echo "<script>alert('Registro removido com sucesso!')</script>";
            echo "<script>window.location='viewAutomovel.php'</script>";
        }
    }

    public static function confirmar()
    {
        if (
            $_POST['placa'] != "" && $_POST['fabricante'] != ""
            && $_POST['modelo'] != ""
           ) {

            // Inserir
            if (empty($_POST['id'])) {
                
                $dados_automovel = array(
                    "placa" => $_POST['placa'],
                    "fabricante" => $_POST['fabricante'],
                    "modelo" => $_POST['modelo']
                );
                modeloAutomovel::addAutomovel($dados_automovel);
                echo "<script>alert('Registro inserido com sucesso!')</script>";

            } else { // Alterar
                $dados_automovel = array(
                    "id" => $_POST['id'],
                    "placa" => $_POST['placa'],
                    "fabricante" => $_POST['fabricante'],
                    "modelo" => $_POST['modelo']
                );
    
                modeloAutomovel::upAutomovel($dados_automovel);
                echo "<script>alert('Registro alterado com sucesso!')</script>";
            }

            echo "<script>window.location='../view/viewAutomovel.php'</script>";
        }
    }

    public static function loadTabelaAutomovels()
    {
        $automovels = modeloAutomovel::getAutomovels();

        while ($objAutomovel = $automovels->fetchObject()) {

            echo "<tr>";
            echo "<td>" . $objAutomovel->id . "</td>";
            echo "<td>" . $objAutomovel->placa . "</td>";
            echo "<td>" . $objAutomovel->fabricante . "</td>";
            echo "<td>" . $objAutomovel->modelo . "</td>";

            echo "<td>";
            echo "<a href='viewAutomovelAlterar.php?id=$objAutomovel->id' class='btn btn-info glyphicon glyphicon-pencil' role='button'></a>";
            echo "<a href='viewAutomovelRemover.php?id=$objAutomovel->id' class='btn btn-danger glyphicon glyphicon-remove' role='button'></a>";
            echo "</td>";
            echo "</tr>";
        }
    }

}