<?php

include_once '../modelo/modeloCliente.php';

class controleCliente
{
    public static function index()
    {
        echo "<script>window.location='../view/viewClienteCadastrar.php'</script>";
    }

    public static function remover($id)
    {
        $cliente = modeloCliente::findCliente($id);

        if (empty($cliente)) {
            echo "<script>alert('O ID informado para o cliente não existe!')</script>";
            echo "<script>window.location='viewCliente.php'</script>";
        } else {
            modeloCliente::delCliente($id);
            echo "<script>alert('Registro removido com sucesso!')</script>";
            echo "<script>window.location='viewCliente.php'</script>";
        }
    }

    public static function confirmar()
    {
        if (
            $_POST['nome'] != "" && $_POST['telefone'] != ""
            && $_POST['cpf'] != "" && $_POST['email'] != ""
           ) {

            // Inserir
            if (empty($_POST['id'])) {
                
                $dados_cliente = array(
                    "nome" => $_POST['nome'],
                    "telefone" => $_POST['telefone'],
                    "cpf" => $_POST['cpf'],
                    "email" => $_POST['email']
                );
                modeloCliente::addCliente($dados_cliente);
                echo "<script>alert('Registro inserido com sucesso!')</script>";

            } else { // Alterar
                $dados_cliente = array(
                    "id" => $_POST['id'],
                    "nome" => $_POST['nome'],
                    "telefone" => $_POST['telefone'],
                    "cpf" => $_POST['cpf'],
                    "email" => $_POST['email']
                );
    
                modeloCliente::upCliente($dados_cliente);
                echo "<script>alert('Registro alterado com sucesso!')</script>";
            }

            echo "<script>window.location='../view/viewCliente.php'</script>";
        }
    }

    public static function loadTabelaClientes()
    {
        $clientes = modeloCliente::getClientes();

        while ($objCliente = $clientes->fetchObject()) {

            echo "<tr>";
            echo "<td>" . $objCliente->id . "</td>";
            echo "<td>" . $objCliente->nome . "</td>";
            echo "<td>" . $objCliente->telefone . "</td>";
            echo "<td>" . $objCliente->cpf . "</td>";
            echo "<td>" . $objCliente->email . "</td>";

            echo "<td>";
            echo "<a href='viewClienteAlterar.php?id=$objCliente->id' class='btn btn-info glyphicon glyphicon-pencil' role='button'></a>";
            echo "<a href='viewClienteRemover.php?id=$objCliente->id' class='btn btn-danger glyphicon glyphicon-remove' role='button'></a>";
            echo "</td>";
            echo "</tr>";
        }
    }

    public static function loadClientes(){

        $clientes = modeloCliente::getClientes();

        while ($objCliente = $clientes->fetchObject()) {

            echo "<option>" . $objCliente->nome . "</option>";

        }
    }
}
