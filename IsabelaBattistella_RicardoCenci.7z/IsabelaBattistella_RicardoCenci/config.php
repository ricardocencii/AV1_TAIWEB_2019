<?php

    class config {
        // Nome do host
        const DB_HOST = 'localhost';
        // Nome do DB
        const DB_NOME = 'db_tai';
        // Usuário do DB
        const DB_USUARIO = 'root';
        // Senha do DB
        const DB_SENHA = '';
        // Charset da conexão PDO
        const DB_CHARSET = 'utf8';
		// TRUE - Apresentar erros / FALSE - Não apresentar erros
        const DEBUG = true;
    }
